/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "UART.h"
#include "TIMER.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
RNG_HandleTypeDef hrng;

TIM_HandleTypeDef htim16;

UART_HandleTypeDef huart2;

/* Definitions for Teller1 */
osThreadId_t Teller1Handle;
const osThreadAttr_t Teller1_attributes = {
  .name = "Teller1",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 256 * 4
};
/* Definitions for ControlTask */
osThreadId_t ControlTaskHandle;
const osThreadAttr_t ControlTask_attributes = {
  .name = "ControlTask",
  .priority = (osPriority_t) osPriorityAboveNormal,
  .stack_size = 320 * 4
};
/* Definitions for Teller2 */
osThreadId_t Teller2Handle;
const osThreadAttr_t Teller2_attributes = {
  .name = "Teller2",
  .priority = (osPriority_t) osPriorityNormal,
  .stack_size = 256 * 4
};
/* Definitions for Teller3 */
osThreadId_t Teller3Handle;
const osThreadAttr_t Teller3_attributes = {
  .name = "Teller3",
  .priority = (osPriority_t) osPriorityLow,
  .stack_size = 256 * 4
};
/* Definitions for customer_queue */
osMessageQueueId_t customer_queueHandle;
const osMessageQueueAttr_t customer_queue_attributes = {
  .name = "customer_queue"
};
/* Definitions for genStatMutex */
osMutexId_t genStatMutexHandle;
const osMutexAttr_t genStatMutex_attributes = {
  .name = "genStatMutex"
};
/* USER CODE BEGIN PV */

uint16_t customer_addition_wait_time = 0;
uint16_t customer_addition_wait_start = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_USART2_UART_Init(void);
static void MX_RNG_Init(void);
static void MX_TIM16_Init(void);
void teller_task(void *argument);
void control_task(void *argument);

/* USER CODE BEGIN PFP */
static gen_stats program_gen_stats = {0,0,0,0,0};
static teller_info teller_1 = {0,0,0,0,0,0,0,0,0,400,0,0,WAITING_FOR_CUSTOMER};
static teller_info teller_2 = {0,0,0,0,0,0,0,0,0,400,0,0,WAITING_FOR_CUSTOMER};
static teller_info teller_3 = {0,0,0,0,0,0,0,0,0,400,0,0,WAITING_FOR_CUSTOMER};
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_RNG_Init();
  MX_TIM16_Init();
  /* USER CODE BEGIN 2 */

  /* USER CODE END 2 */

  /* Init scheduler */
  osKernelInitialize();
  /* Create the mutex(es) */
  /* creation of genStatMutex */
  genStatMutexHandle = osMutexNew(&genStatMutex_attributes);

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */

  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of customer_queue */
  customer_queueHandle = osMessageQueueNew (64, sizeof(uint16_t), &customer_queue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of Teller1 */
  Teller1Handle = osThreadNew(teller_task, (void*) &teller_1, &Teller1_attributes);

  /* creation of ControlTask */
  ControlTaskHandle = osThreadNew(control_task, NULL, &ControlTask_attributes);

  /* creation of Teller2 */
  Teller2Handle = osThreadNew(teller_task, (void*) &teller_2, &Teller2_attributes);

  /* creation of Teller3 */
  Teller3Handle = osThreadNew(teller_task, (void*) &teller_3, &Teller3_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

  /* Start scheduler */
  osKernelStart();

  /* We should never get here as control is now taken by the scheduler */
  /* Infinite loop */
  /* USER CODE BEGIN WHILE */


  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }
  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV4;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART2|RCC_PERIPHCLK_RNG;
  PeriphClkInit.Usart2ClockSelection = RCC_USART2CLKSOURCE_PCLK1;
  PeriphClkInit.RngClockSelection = RCC_RNGCLKSOURCE_PLLSAI1;
  PeriphClkInit.PLLSAI1.PLLSAI1Source = RCC_PLLSOURCE_MSI;
  PeriphClkInit.PLLSAI1.PLLSAI1M = 1;
  PeriphClkInit.PLLSAI1.PLLSAI1N = 16;
  PeriphClkInit.PLLSAI1.PLLSAI1P = RCC_PLLP_DIV7;
  PeriphClkInit.PLLSAI1.PLLSAI1Q = RCC_PLLQ_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1R = RCC_PLLR_DIV2;
  PeriphClkInit.PLLSAI1.PLLSAI1ClockOut = RCC_PLLSAI1_48M2CLK;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief RNG Initialization Function
  * @param None
  * @retval None
  */
static void MX_RNG_Init(void)
{

  /* USER CODE BEGIN RNG_Init 0 */

  /* USER CODE END RNG_Init 0 */

  /* USER CODE BEGIN RNG_Init 1 */

  /* USER CODE END RNG_Init 1 */
  hrng.Instance = RNG;
  if (HAL_RNG_Init(&hrng) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN RNG_Init 2 */

  /* USER CODE END RNG_Init 2 */

}

/**
  * @brief TIM16 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM16_Init(void)
{

  /* USER CODE BEGIN TIM16_Init 0 */

  /* USER CODE END TIM16_Init 0 */

  /* USER CODE BEGIN TIM16_Init 1 */

  /* USER CODE END TIM16_Init 1 */
  htim16.Instance = TIM16;
  htim16.Init.Prescaler = 40000-1;
  htim16.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim16.Init.Period = 65535;
  htim16.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim16.Init.RepetitionCounter = 0;
  htim16.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim16) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM16_Init 2 */

  /* USER CODE END TIM16_Init 2 */

}

/**
  * @brief USART2 Initialization Function
  * @param None
  * @retval None
  */
static void MX_USART2_UART_Init(void)
{

  /* USER CODE BEGIN USART2_Init 0 */

  /* USER CODE END USART2_Init 0 */

  /* USER CODE BEGIN USART2_Init 1 */

  /* USER CODE END USART2_Init 1 */
  huart2.Instance = USART2;
  huart2.Init.BaudRate = 9600;
  huart2.Init.WordLength = UART_WORDLENGTH_8B;
  huart2.Init.StopBits = UART_STOPBITS_1;
  huart2.Init.Parity = UART_PARITY_NONE;
  huart2.Init.Mode = UART_MODE_TX_RX;
  huart2.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart2.Init.OverSampling = UART_OVERSAMPLING_16;
  huart2.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart2.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart2) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART2_Init 2 */

  /* USER CODE END USART2_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();

}

/* USER CODE BEGIN 4 */

// Purpose: 	Gets a random uint32_t within a given range, used to get wait times
// Input:		min: Minimum Value; max: Maximum Value
// Output:		A random uint32_t within the given range
uint32_t get_random_value_range(uint32_t min, uint32_t max){
	uint32_t *randval;			//Pointer for random value
	uint32_t module;			//Working var
	// Gets a random number
	HAL_RNG_GenerateRandomNumber(&hrng, &randval);

	// Get in range using: (rand_num % (max - min +1)) + min
	module = max - min;
	module += 1;
	module = (uint32_t) randval % (uint32_t)module;
	return module + min;
}
// Purpose: 	Converts actual time to simulated minutes
// Input:		time: the actual time of the operation
// Output:		the value in minutes
double milliseconds_to_sim_minutes(uint16_t time){
	double mins =  (double)time/100;
	return mins;
}

// Purpose: 	Takes the elapsed real time, and converts it to simulated time
// Input:		Start time of the application
// Output:		String for the simulated time
const char* get_current_time(uint16_t start_time){
	//Get elapsed_time
	uint16_t elapsed_time = get_wait_timer(htim16) - start_time;

	//Convert to sim time
	uint16_t sim_minutes_elapsed = elapsed_time/100;

	//Get hours and minutes
	uint16_t hours = sim_minutes_elapsed / 60;
	uint16_t minutes = sim_minutes_elapsed % 60;

	//add to 9 (start time)
	uint16_t hour = 9 + hours;
	// past noon
	if(hour > 12){
		// subtract 12 for 12 hour clock
		hour = hour - 12;
	}

	//Create the string
	char time_str[5];
	if(minutes < 10){
		sprintf(time_str,"%d:0%d",hour,minutes);
	}
	else{
		sprintf(time_str,"%d:%d",hour,minutes);
	}
	char *pointer = time_str;
	return pointer;
}
// Purpose: 	converts the teller status to a string
// Input:		Teller Status Enum
// Output:		Teller Status as a string
const char* teller_status_to_str(status teller_status){
	char *pointer;
	switch(teller_status){
		case WAITING_FOR_CUSTOMER:
			pointer = "idle";
			break;
		case ON_BREAK:
			pointer = "on break";
			break;
		case WITH_CUSTOMER:
			pointer = "busy";
			break;
	}
	return pointer;
}
/* USER CODE END 4 */

/* USER CODE BEGIN Header_teller_task */
/**
  * @brief  Function implementing the Teller1 thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_teller_task */
void teller_task(void *argument)
{
  /* USER CODE BEGIN 5 */
	uint16_t msg;							//The message from queue (time when customer was added to the queue)
	teller_info *teller = argument;

	uint16_t customer_wait_time;			//Used for calculating how long the customer has waited
	uint16_t teller_wait_time;				//Wait time for teller
	uint32_t delay_time = DEFAULT_TELLER_DELAY_TIME;	//The delay time
	/* Infinite loop */
	for(;;)
	{
		//Check if break is over. Also used to initalize the break with the or
		if(teller->teller_status == ON_BREAK || teller->next_break_time == 0){
			// If Break Over
			if(get_wait_timer(htim16) - teller->break_start >= teller->break_time){
				// End break
				teller->teller_status = WAITING_FOR_CUSTOMER;
				// Set up next break
				teller->last_break_end = get_wait_timer(htim16);
				teller->next_break_time = get_random_value_range(TELLER_BREAK_INTERVAL_MIN, TELLER_BREAK_INTERVAL_MAX);
			}
		}
		else{
			// Check to see if we are running an operation against timer 16
			if(teller->operation_time == 0 || get_wait_timer(htim16) - teller->operation_start_time >= teller->operation_time){
				if(get_wait_timer(htim16) - teller->last_break_end >= teller->next_break_time ){
					//Set break
					teller->teller_status = ON_BREAK;
					teller->break_start = get_wait_timer(htim16);
					teller->break_time = get_random_value_range(TELLER_BREAK_TIME_MIN,TELLER_BREAK_TIME_NAX);
					//Update Metrics
					teller->break_count += 1;
					teller->total_break_time += teller->break_time;
					if(teller->break_time > teller->longest_break){
						teller->longest_break = teller->break_time;
					}
					if(teller->break_time < teller->shortest_break){
						teller->shortest_break = teller->break_time;
					}
				}
				else{
					// Start wait for customer timer
					teller->wait_for_customer_start_time = get_wait_timer(htim16);
					teller->teller_status = WAITING_FOR_CUSTOMER;
					//Check if break time

					//If not take in new customer
					if( osMessageQueueGet(customer_queueHandle,&msg, NULL, osWaitForever) == osOK){
						teller->teller_status = WITH_CUSTOMER;
						//update statistics
						if(osMutexAcquire(genStatMutexHandle, osWaitForever)==osOK){
							//add one to tellers individual stats
							teller->customer_served+=1;

							//add new customer served
							program_gen_stats.customers_served+=1;
							//get wait time
							customer_wait_time = get_wait_timer(htim16) - msg;
							//add to total wait time
							program_gen_stats.customer_total_wait_time_in_queue += customer_wait_time;
							//See if new max
							if(program_gen_stats.customer_max_wait_time_in_queue < customer_wait_time){
								program_gen_stats.customer_max_wait_time_in_queue = customer_wait_time;
							}

							// Update wait time metrics
							teller_wait_time = get_wait_timer(htim16) - teller->wait_for_customer_start_time;
							program_gen_stats.teller_total_wait_times += teller_wait_time;
							//See if new max
							if(program_gen_stats.max_teller_wait_time < teller_wait_time){
								program_gen_stats.max_teller_wait_time = teller_wait_time;
							}

							//set up operation time
							delay_time = get_random_value_range(CUSTOMER_TRANSACTION_TIME_MIN, CUSTOMER_TRANSACTION_TIME_MAX);
							//add to total operation time
							program_gen_stats.total_operation_time += delay_time;
							if(program_gen_stats.max_operation_time < delay_time){
								program_gen_stats.max_operation_time = delay_time;
							}
						}
						osMutexRelease(genStatMutexHandle);
						//run operation
						teller->operation_time = delay_time;
						teller->operation_start_time = get_wait_timer(htim16);
					}
				}

			}
		}
		//Delay so other tasks can run
		osDelay(delay_time);
	}
  /* USER CODE END 5 */
}

/* USER CODE BEGIN Header_control_task */
/**
* @brief Function implementing the ControlTask thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_control_task */
void control_task(void *argument)
{
  /* USER CODE BEGIN control_task */
	uint32_t wait_time;								//Wait Time for adding customer to queue
	uint32_t delay_time = DELAY_TIME_CONTROL ;		//osDelay Time for temp pausing of the process
	uint16_t message;								//The message added to the queue
	uint8_t closed = 0;								//Flag for printing closed bank

	//Start the program timer
	start_timer(htim16);
	//Get start time
	uint16_t start_time = get_wait_timer(htim16);

	//Init UART Vars
	uint8_t uart_buffer[UART_BUFFER];
	uint32_t uart_buffer_size;

	uint16_t interator = 0; 						//As is printing real time is too fast, we want to print every 20 cycles = every 100m/s or every sim minute

	//Bank Open Message
	uart_buffer_size = sprintf((char *)uart_buffer, "Opening Bank\r\n");
	uart_transmit(&huart2, uart_buffer, uart_buffer_size);


	  /* Infinite loop */
	 for(;;)
	  {
		 if(interator == 20 ){
		 //Print running status
			 interator = 0;
//
			uart_buffer_size = sprintf((char *)uart_buffer, "\033[2J");
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);

			 //current time
			uart_buffer_size = sprintf((char *)uart_buffer, "Current Time: %s\r\n", get_current_time(start_time));
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);

			//customers in queue
			uart_buffer_size = sprintf((char *)uart_buffer, "Customers in Queue: %d\r\n", osMessageQueueGetCount(customer_queueHandle));
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);

			//teller customer served totals and status
			uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Customers Served: %d\t",teller_1.customer_served);
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);
			uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Status: %s\r\n",teller_status_to_str(teller_1.teller_status));
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);


			uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Customers Served: %d\t",teller_2.customer_served);
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);
			uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Status: %s\r\n",teller_status_to_str(teller_2.teller_status));
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);

			uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Customers Served: %d\t",teller_3.customer_served);
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);
			uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Status: %s\r\n",teller_status_to_str(teller_3.teller_status));
			uart_transmit(&huart2, uart_buffer, uart_buffer_size);;


		 }

		 //check if bank still open
		 if(get_wait_timer(htim16) - start_time <= SIMULATION_TIME){
			 //Check if wait time 0, meaning starting program || wait time for customer has elapsed
			 if(customer_addition_wait_time==0 || get_wait_timer(htim16) - customer_addition_wait_start >= customer_addition_wait_time){
				 // Add customer to message queue
				message = get_wait_timer(htim16);
				if( osMessageQueuePut(customer_queueHandle,(void *)&message ,NULL, osWaitForever) == osOK){

					//Check if new max queue length
					if(osMutexAcquire(genStatMutexHandle, osWaitForever)==osOK){
						if(osMessageQueueGetCount(customer_queueHandle) > program_gen_stats.max_queue_depth){
							program_gen_stats.max_queue_depth = osMessageQueueGetCount(customer_queueHandle);
						}
					}
					osMutexRelease(genStatMutexHandle);

					//Set wait for next customer
					wait_time = get_random_value_range(CUSTOMER_ARRIVAL_TIME_MIN, CUSTOMER_ARRIVAL_TIME_MAX);
					customer_addition_wait_time = wait_time;
					customer_addition_wait_start = get_wait_timer(htim16);
				}
			 }

		 }
		 //Bank closed
		 else{
			 if(!closed){
				 closed = 1;
				 uart_buffer_size = sprintf((char *)uart_buffer, "Closing Bank, No more customers will enter, remaining customers will be served\r\n");
				 uart_transmit(&huart2, uart_buffer, uart_buffer_size);
			 }
			 //queue is empty and thread is blocked(ie waiting for new customer)
			 if(osMessageQueueGetCount(customer_queueHandle)==0 &&
					 osThreadGetState(Teller1Handle) == osThreadBlocked &&
					 osThreadGetState(Teller2Handle) == osThreadBlocked &&
					 osThreadGetState(Teller3Handle) == osThreadBlocked){
				 if(osMutexAcquire(genStatMutexHandle, osWaitForever)==osOK){
					 uart_buffer_size = sprintf((char *)uart_buffer, "Sim Over\r\n");
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 1 (Total Customers served)
					 uart_buffer_size = sprintf((char *)uart_buffer, "Customers Served: %d\r\n", program_gen_stats.customers_served);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 2 (Customers Served by Tellers)
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Customers Served: %d\r\n", teller_1.customer_served);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Customers Served: %d\r\n", teller_2.customer_served);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Customers Served: %d\r\n", teller_3.customer_served);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 3 (Average Time in Queue)
					 program_gen_stats.customer_total_wait_time_in_queue = program_gen_stats.customer_total_wait_time_in_queue / program_gen_stats.customers_served;
					 uart_buffer_size = sprintf((char *)uart_buffer, "Average Wait Time: %f mins\r\n", milliseconds_to_sim_minutes(program_gen_stats.customer_total_wait_time_in_queue));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 4 (Average Time with a Teller)
					 program_gen_stats.total_operation_time = program_gen_stats.total_operation_time / program_gen_stats.customers_served;
					 uart_buffer_size = sprintf((char *)uart_buffer, "Average Time with Teller: %f mins.\r\n", milliseconds_to_sim_minutes(program_gen_stats.total_operation_time));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 5 (average wait for customer)
					 program_gen_stats.teller_total_wait_times = program_gen_stats.teller_total_wait_times / program_gen_stats.customers_served;
					 uart_buffer_size = sprintf((char *)uart_buffer, "Average Time Tellers Wait for Customer: %f mins.\r\n", milliseconds_to_sim_minutes(program_gen_stats.teller_total_wait_times));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 6 (Max Wait Time)
					 uart_buffer_size = sprintf((char *)uart_buffer, "Max Queue Wait Time: %f mins\r\n", milliseconds_to_sim_minutes(program_gen_stats.customer_max_wait_time_in_queue));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 7 (Max Wait for customer time)
					 uart_buffer_size = sprintf((char *)uart_buffer, "Max Teller Wait Time For Customer: %f mins\r\n", milliseconds_to_sim_minutes(program_gen_stats.max_teller_wait_time));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 8 (Max Transaction Time)
					 uart_buffer_size = sprintf((char *)uart_buffer, "Max Transaction Time: %f mins\r\n", milliseconds_to_sim_minutes(program_gen_stats.max_operation_time));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 9 (Max Customer Queue Depth)
					 uart_buffer_size = sprintf((char *)uart_buffer, "Largest the Queue was: %d\r\n", program_gen_stats.max_queue_depth);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //BREAK STATS
					 //Metric 10, Breaks per teller
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Breaks: %d\t", teller_1.break_count);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Breaks: %d\t", teller_2.break_count);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Breaks: %d\t\r\n", teller_3.break_count);
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 11, Average Break Per Teller
					 teller_1.total_break_time = teller_1.total_break_time/teller_1.break_count;
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Average Break Time: %f mins\t", milliseconds_to_sim_minutes(teller_1.total_break_time));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 teller_2.total_break_time = teller_2.total_break_time/teller_2.break_count;
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Average Break Time: %f mins\t", milliseconds_to_sim_minutes(teller_2.total_break_time));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 teller_3.total_break_time = teller_3.total_break_time/teller_3.break_count;
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Average Break Time: %f mins\t\r\n", milliseconds_to_sim_minutes(teller_3.total_break_time));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 12, Max Break Time
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Longest Break Time: %f mins\t", milliseconds_to_sim_minutes(teller_1.longest_break));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Longest Break Time: %f mins\t", milliseconds_to_sim_minutes(teller_2.longest_break));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Longest Break Time: %f mins\t\r\n", milliseconds_to_sim_minutes(teller_3.longest_break));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 //Metric 13, Min Break Time
					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 1 Shortest Break Time: %f mins\t", milliseconds_to_sim_minutes(teller_1.shortest_break));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 2 Shortest Break Time: %f mins\t", milliseconds_to_sim_minutes(teller_2.shortest_break));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);

					 uart_buffer_size = sprintf((char *)uart_buffer, "Teller 3 Shortest Break Time: %f mins\t\r\n", milliseconds_to_sim_minutes(teller_3.shortest_break));
					 uart_transmit(&huart2, uart_buffer, uart_buffer_size);



				 }
				 osMutexRelease(genStatMutexHandle);
				 //End
				 osThreadTerminate(ControlTaskHandle);
			 }
		 }
		 interator++;
		 //Enter Delay to allow other tasks to run
		 osDelay(delay_time);
	  }
  /* USER CODE END control_task */
}

 /**
  * @brief  Period elapsed callback in non blocking mode
  * @note   This function is called  when TIM6 interrupt took place, inside
  * HAL_TIM_IRQHandler(). It makes a direct call to HAL_IncTick() to increment
  * a global variable "uwTick" used as application time base.
  * @param  htim : TIM handle
  * @retval None
  */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
  /* USER CODE BEGIN Callback 0 */

  /* USER CODE END Callback 0 */
  if (htim->Instance == TIM6) {
    HAL_IncTick();
  }
  /* USER CODE BEGIN Callback 1 */

  /* USER CODE END Callback 1 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
