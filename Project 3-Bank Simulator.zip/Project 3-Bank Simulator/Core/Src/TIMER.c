/*
 * TIMER.c
 *
 *  Created on: Mar 29, 2021
 *      Author: Stephen
 */



#include "TIMER.h"
void start_timer(TIM_HandleTypeDef timer){
	HAL_TIM_Base_Start(&timer);
}
void stop_timer(TIM_HandleTypeDef timer){
	HAL_TIM_Base_Start(&timer);
}
uint16_t get_wait_timer(TIM_HandleTypeDef timer){
	return __HAL_TIM_GET_COUNTER(&timer);
}

