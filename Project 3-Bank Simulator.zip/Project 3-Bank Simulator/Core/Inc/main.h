/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * <h2><center>&copy; Copyright (c) 2021 STMicroelectronics.
  * All rights reserved.</center></h2>
  *
  * This software component is licensed by ST under BSD 3-Clause license,
  * the "License"; You may not use this file except in compliance with the
  * License. You may obtain a copy of the License at:
  *                        opensource.org/licenses/BSD-3-Clause
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
typedef enum {
	WAITING_FOR_CUSTOMER,
	WITH_CUSTOMER,
	ON_BREAK,
}status;

typedef struct{
	//For Metric 1, total number of customers served
	uint8_t customers_served;

	//For Metric 3, average time in queue (average time = (total wait time)/customers served
	uint16_t customer_total_wait_time_in_queue;

	//For metric 4, average time spent with teller (average time = (total time)/customers served
	uint16_t total_operation_time;

	//For Metric 5, average time waiting for customers ( average time = (total wait time)/customers served )
	uint16_t teller_total_wait_times;

	//For metric 6, max wait time in queue
	uint16_t customer_max_wait_time_in_queue;

	//For metric 7, max teller wait time
	uint16_t max_teller_wait_time;

	//For metric 8, max transaction time
	uint16_t max_operation_time;

	//For metric 9, max depth of queue
	uint32_t max_queue_depth;
}gen_stats;

typedef struct{

	//operation time stuff
	uint16_t operation_time;
	uint16_t operation_start_time;

	//Breaks
	uint16_t break_start;
	uint16_t break_time;
	uint16_t last_break_end;
	uint16_t next_break_time;

	//Break Metrics
	uint16_t break_count;
	uint16_t total_break_time;
	uint16_t longest_break;
	uint16_t shortest_break;


	//Used to time waits
	uint16_t wait_for_customer_start_time;

	//For Metric 2, Served by a teller
	uint16_t customer_served;

	status teller_status;
}teller_info;


/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */
//RUN TIME = 7 hours
//Default rtos tick rate = 1m/s
//Given simulation runs 1 min at 100m/s, 7 hours is 420 min * 100 = 42,000 m/s or 42 sec
#define SIMULATION_TIME (42000)

//CUSTOMER ARRIVAL RATE: 1-4 min
//Default rtos tick rate = 1m/s
//Given simulation runs 1min at 100m/s, 1min is 100 and 4min 400
#define CUSTOMER_ARRIVAL_TIME_MIN (100)				//Min Time before new customer arrives
#define CUSTOMER_ARRIVAL_TIME_MAX (400)				//Max time before customer arrives

//CUSTOMER TRANSACTION TIME: 30sec - 8min
//Default rtos tick rate = 1m/s
//Given simulation runs 1min at 100m/s, 30sec is 30 and 8min 800
#define CUSTOMER_TRANSACTION_TIME_MIN (30)		//Min Transaction Time
#define CUSTOMER_TRANSACTION_TIME_MAX (800)		//Max Transaction Time


//TELLER BREAK RATE: 30-60mins
//Default rtos tick rate = 1m/s
//Given simulation runs 1min at 100m/s, 30mins is 3000 and 60min 6000
#define TELLER_BREAK_INTERVAL_MIN (3000)		//Min Break Time
#define TELLER_BREAK_INTERVAL_MAX (6000)		//Max Break Time

//TELLER BREAK TIME: 1 - 4 min
//Default rtos tick rate = 1m/s
//Given simulation runs 1min at 100m/s, 1min is 100 and 4min 400
#define TELLER_BREAK_TIME_MIN (100)				//Min Time for a tellers break
#define TELLER_BREAK_TIME_NAX (400)				//Max time for a tellers break

#define DELAY_TIME_CONTROL (5);				//Delay time of controller
#define DEFAULT_TELLER_DELAY_TIME (5);		//Delay time for tellers


/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
/* USER CODE BEGIN Private defines */

/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */

/************************ (C) COPYRIGHT STMicroelectronics *****END OF FILE****/
