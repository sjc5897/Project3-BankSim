/*
 * TIMER.h
 *
 *  Created on: Mar 29, 2021
 *      Author: Stephen
 */

#ifndef INC_TIMER_H_
#define INC_TIMER_H_
#include "stm32l4xx_hal.h"

void start_timer(TIM_HandleTypeDef timer);
void stop_timer(TIM_HandleTypeDef timer);
uint16_t get_wait_timer(TIM_HandleTypeDef timer);

#endif /* INC_TIMER_H_ */
